/*

This is a piece of text.

It is not a graph, and will not draw anything.

However, it is a useful example of a chunk of text that might be included within a CED/ZIP file for the benefit of the user.

As with all data in a CED/ZIP file it is just text and can be accessed by anybody on any operating system, even if they don't have mtCellEdit.

*/
